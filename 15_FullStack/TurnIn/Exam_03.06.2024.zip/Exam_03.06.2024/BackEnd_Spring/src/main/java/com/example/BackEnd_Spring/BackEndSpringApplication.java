package com.example.BackEnd_Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndSpringApplication.class, args);
	}

}
