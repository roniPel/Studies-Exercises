package com.example.BackEnd_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
