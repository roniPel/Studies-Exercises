export class Person{
    public id:number;
    public name:string;
    public phoneNum:number;

    constructor(id:number,name:string,phoneNum:number){
        this.id = id;
        this.name = name;
        this.phoneNum = phoneNum;
    }
}