import "./Header.css";

export function Header(): JSX.Element {
    return (
        <div className="Header">
			<h1>Task System</h1>
        </div>
    );
}
