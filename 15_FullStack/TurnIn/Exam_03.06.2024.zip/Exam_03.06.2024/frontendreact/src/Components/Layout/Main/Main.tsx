import "./Main.css";

export function Main(): JSX.Element {
    return (
        <div className="Main">
			
        </div>
    );
}
