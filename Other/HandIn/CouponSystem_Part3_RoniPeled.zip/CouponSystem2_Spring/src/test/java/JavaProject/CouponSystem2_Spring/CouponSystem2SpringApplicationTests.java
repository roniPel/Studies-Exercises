package JavaProject.CouponSystem2_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponSystem2SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
