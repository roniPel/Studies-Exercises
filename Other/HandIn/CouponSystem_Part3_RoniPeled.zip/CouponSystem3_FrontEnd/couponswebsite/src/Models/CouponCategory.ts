enum CouponCategory{
    Food='Food',
    Electricity='Electricity',
    Restaurant='Restaurant',
    Vacation='Vacation',
    Toys='Toys',
    Automotive='Automotive',
    Tires='Tires',
    BabyToddler='BabyToddler',
    Computers='Computers',
    CellPhones='CellPhones',
    Televisions='Televisions',
    VideoGamesConsoles='VideoGamesConsoles',
}

  export {CouponCategory}