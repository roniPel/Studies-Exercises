import "./footer.css";

export function Footer(): JSX.Element {
    return (
        <div className="footer">
			all rights reseved to Roni Peled (c)
        </div>
    );
}
