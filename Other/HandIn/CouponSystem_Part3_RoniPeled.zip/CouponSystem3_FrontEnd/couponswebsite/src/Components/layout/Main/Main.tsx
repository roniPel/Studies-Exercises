import "./Main.css";

export function Main(): JSX.Element {
    return (
        <div className="Main">
			<h1>Uri Moto in life</h1>
            <h2>We no need no, education....</h2>
        </div>
    );
}
