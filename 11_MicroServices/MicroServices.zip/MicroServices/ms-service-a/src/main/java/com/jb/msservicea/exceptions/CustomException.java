package com.jb.msservicea.exceptions;


public class CustomException extends Throwable{
    public CustomException(String message) {
        super(message);
    }
}
