package com.js.msgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
